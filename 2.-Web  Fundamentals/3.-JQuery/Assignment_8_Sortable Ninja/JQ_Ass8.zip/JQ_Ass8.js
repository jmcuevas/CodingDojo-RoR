$('document').ready(function() {
  $('#sortable_images').sortable();
})
