module GeneratorHelper
end
