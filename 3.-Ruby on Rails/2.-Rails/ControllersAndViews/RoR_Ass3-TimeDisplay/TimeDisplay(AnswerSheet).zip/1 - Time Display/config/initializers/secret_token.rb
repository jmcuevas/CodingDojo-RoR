# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
TimeDisplay::Application.config.secret_key_base = 'a30f5ce562e9c87556a72770f3df3f59a4322fd2a66ae59caa5e5f0ce4de15ec33c2530e6cf228991d4e67b6019d838bc7d5bebbe07cb1596b0f660a3c54e7cd'
