require 'test_helper'

class NumbersHelperTest < ActionView::TestCase
end
