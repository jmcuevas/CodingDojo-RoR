class NumbersController < ApplicationController
	def index
		# If a random number is not yet present, generate by calling the private function: generate_random_number
		generate_random_number if !session[:random].present?
	end

	def create
		# Default values of flash
		flash[:message] = 'You got it!'
		flash[:status] = false

		# Check if a number was submitted
		if params[:number].present?
			input_number = params[:number].to_i

			if input_number > session[:random] 
				flash[:message] = 'Too High'
			elsif input_number < session[:random]
				flash[:message] = 'Too Low'
			else
				generate_random_number
				flash[:status] = true
			end
		else
			flash[:message] = '# please'
		end

		redirect_to action: 'index'
	end

	private
	# Generate random number from 1 - 100
	def generate_random_number
		session[:random] = rand(1..100)
	end
end
